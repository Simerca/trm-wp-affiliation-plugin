<?php

$idProduct = get_the_ID();


?>

<div class="colonne-12">

    <a href="?m_wishlist=<?php echo $idProduct; ?>">Ajouter à ma wishlist</a>

</div>